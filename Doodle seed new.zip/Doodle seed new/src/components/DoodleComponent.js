import React, { Component, PropTypes } from 'react';
//this.props.currItems is an object that has server data 
export default class DoodleComponent extends Component {
	constructor(props){
		super(props);
		this.state ={
			fontName : 'impact',
			backUrl :'http://cdn8.staztic.com/app/a/6278/6278761/hd-abstract-wallpapers-1-0-s-307x512.jpg',
			dummyClassName2 : 'clip-text_one',
			dummyClassName1 : 'clip-text'
		}
	}
	
	render(){
		var styleObj = {
		fontFamily :this.state.fontName,
		backgroundImage: `url(${this.state.backUrl})`

	}
		return (
			<figure className="grid-figure">
			<div className="wrapper">
			<div className={`${this.state.dummyClassName1} ${this.state.dummyClassName2}`} style={styleObj} >
				{this.props.userInputs.userText}
			</div>
			</div>
			</figure>
			);
	}
}

