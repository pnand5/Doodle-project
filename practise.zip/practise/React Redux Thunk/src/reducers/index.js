import { combineReducers } from 'redux';
import { items, itemsHasErrored, itemsIsLoading,addData } from './items';

export default combineReducers({
    items,
    itemsHasErrored,
    itemsIsLoading,
    addData
});
