import React, { Component, PropTypes } from 'react';

import DoodleComponent from './DoodleComponent';

export default class DoodleList extends Component {
	
	
	render(){
		var myDoodleChildren = this.props.props.items.map((items,index)=> 	{
			return <DoodleComponent currItem={items} i={index} userInputs={this.props.state}/>
		});

		return ( <div>
				{myDoodleChildren}
				</div>
			);
		}
}