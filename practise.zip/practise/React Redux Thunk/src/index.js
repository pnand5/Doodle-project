import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import configureStore from './store/configureStore';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';


import ContainerComponent from './components/ContainerComponent';
import ShoppingMain from './components/ShoppingMain';
import SingleProductDetailsComponent from './components/SingleProductDetailsComponent';
import CartComponent from './components/CartComponent'
const store = configureStore({addData:[]});

render(
    <Provider store={store}>

		<Router history={browserHistory}>
			<Route path="/" component={ContainerComponent}>
				<IndexRoute component={ShoppingMain}> </IndexRoute>
                <Route path="/spdc/:id" component={SingleProductDetailsComponent}> </Route>
                <Route path="/cart/:id" component={CartComponent}> </Route>
                
			</Route>
			
		</Router>

		</Provider>,
    document.getElementById('app')
);
