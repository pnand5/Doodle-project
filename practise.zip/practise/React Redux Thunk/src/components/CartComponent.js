import React, { Component, PropTypes } from 'react';

export default class CartComponent extends Component {
    constructor(props) {
        super(props);
        this.state= {
            
        }
    }
    render() {
        return (
            <div>
                    
            </div>
        );
    }
}