import React, { Component, PropTypes } from 'react';
import {bindActionCreators} from 'redux';

import { connect } from 'react-redux';
import { itemsFetchData,addDataToStore } from '../actions/items';

class ContainerComponent extends Component {
    componentDidMount() {
        this.props.fetchData('https://jsonplaceholder.typicode.com/photos');
    }

    render() {
        if (this.props.hasErrored) {
            return <p>Sorry! There was an error loading the items</p>;
        }

        if (this.props.isLoading) {
            return <p>Loading…</p>;
        }

        return (
            <div >
        
                {React.cloneElement(this.props.children, this.props) } 
           
            </div>
        );
    }
}

ContainerComponent.propTypes = {
    fetchData: PropTypes.func.isRequired,
    items: PropTypes.array.isRequired,
    hasErrored: PropTypes.bool.isRequired,
    isLoading: PropTypes.bool.isRequired
};

const mapStateToProps = (state) => {
    return {
        items: state.items,
        hasErrored: state.itemsHasErrored,
        isLoading: state.itemsIsLoading,
        addData: state.addData
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        
        fetchData: (url) => dispatch(itemsFetchData(url)),
       addDataToStore: (id) => dispatch(addDataToStore(id))
        
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ContainerComponent);
