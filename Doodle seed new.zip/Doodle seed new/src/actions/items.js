import axios from 'axios';
export function itemsHasErrored(bool) {
    return {
        type: 'ITEMS_HAS_ERRORED',
        hasErrored: bool
    };
}

export function itemsIsLoading(bool) {
    return {
        type: 'ITEMS_IS_LOADING',
        isLoading: bool
    };
}

export function itemsFetchDataSuccess(items) {
    return {
        type: 'ITEMS_FETCH_DATA_SUCCESS',
        items
    };
}

export function itemsFetchData(url,data=undefined) {
    console.log("isnde items fethvhing")
    return (dispatch) => {

        dispatch(itemsIsLoading(true));
        if(data) {
            return axios({
                url :url,
                timeout: 20000,
                method: 'post',
                data,
                responseType: 'json'
            })
            .then(function(response){
                dispatch(itemsFetchDataSuccess(response.data));
                dispatch(itemsIsLoading(false));
            })
            .catch(function(response){
                dispatch(itemsHasErrored(response.data));
            })
        }
        else if(!data) {
            return axios({
                url :url,
                timeout: 20000,
                method: 'get',
                responseType: 'json'
            })
            .then(function(response){
                dispatch(itemsFetchDataSuccess(response.data));
                dispatch(itemsIsLoading(false));
            })
            .catch(function(response){
                dispatch(itemsHasErrored(response.data));
            })
        }

        // fetch(url)
        //     .then((response) => {
        //         if (!response.ok) {
        //             throw Error(response.statusText);
        //         }

        //         dispatch(itemsIsLoading(false));

        //         return response;
        //     })
        //     .then((response) => response.json())
        //     .then((items) => dispatch(itemsFetchDataSuccess(items)))
        //     .catch(() => dispatch(itemsHasErrored(true)));
    };
}
