import React, { Component, PropTypes } from 'react';

import {Link} from 'react-router';


export default class InputComponent extends Component {
    constructor(props){
      super(props);
    }
    // componentDidMount() {
    //   console.log('inside InputComponent componentDidMount')
    // this.props.props.fetchData('https://jsonplaceholder.typicode.com/posts');

    // }

   
    render() {
     
        return (
         < div id="inputComp">
            < h2 className = "text-center" > PROVIDE INFORMATION < /h2> 
            < form className="formBox" ref="formBox" onSubmit={this.props.onSubmit1}>
            	< div className={this.props.formGroupClass(this.props.state.errors.userText)}>
            		< label htmlFor = "textArea" className="control-label">DOODLE Text Goes Here < /label> 
            		< textarea onChange={this.props.onChange1} id = "textArea" className="form-control" ref="userText" name="userText"> < /textarea>
                 <span className="help-block"> {this.props.state.errors.userText} </span>
            	</div>
            	< div className={this.props.formGroupClass(this.props.state.errors.datePick)}>
            		< label htmlFor = "datePick" className="control-label">Select date (mm/dd/yy)< /label> 
            		<input onChange={this.props.onChange1} type="date" ref="datePick" name="datePick" className="form-control"></input>
                 <span className="help-block"> {this.props.state.errors.datePick} </span>

            	</div>
            	<div className={this.props.formGroupClass(this.props.state.errors.category)}>
            		<label htmlFor="category" className="control-label"> Choose Events </label>
            		<select onChange={this.props.onChange1} name="category" ref="category" className="form-control">
  						        <option value="" selected disabled>Categories</option>
  						        <option value="volvo">Volvo</option>
  						        <option value="saab">Saab</option>
  						        <option value="fiat">Fiat</option>
  						        <option value="audi">Audi</option>
					</select>
                 <span className="help-block"> {this.props.state.errors.category} </span>

            	</div>
            	< div className={this.props.formGroupClass(this.props.state.errors.numberDoodle)}>
            		< label htmlFor = "numberDoodle" className="control-label">Number of Doodles MAX(20)< /label> 
            		<input onChange={this.props.onChange1} type="number" name="numberDoodle" ref="numberDoodle" className="form-control" max="20"></input>
                 <span className="help-block"> {this.props.state.errors.numberDoodle} </span>

            	</div>
            	<div id="buttonElement">
   			      
            	<button type="submit" className="btn btn-info btn-md" >HIT </button>

            	</div>
             < /form>
              
             
         </div> );
        }
    }
