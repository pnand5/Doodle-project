import React, { Component, PropTypes } from 'react';

import SingleProductComponent from './SingleProductComponent';

export default class ShoppingMain extends Component{
    constructor(props){
        super(props);
    }
    render()
    { var photoList = this.props.items.map((object,index)=> {
                       return (<SingleProductComponent currItem = {object} key={index} {...this.props}/>)
                        });
        return (
             <div >
            <h1> Welcome to E-Shopping LIMITED </h1>
               
                    <div className="row" >
                       
                           {photoList}
                   
                    </div>
                </div>  
        );
    }
}