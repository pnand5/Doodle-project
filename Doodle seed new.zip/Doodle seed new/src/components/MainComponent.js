import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import ReactChildrenCloneWithProps from 'react-children-clone-with-props';
// import {Router} from 'react-router';
// import { pushState } from 'redux-router';
import { browserHistory } from 'react-router';
import { itemsFetchData } from '../actions/items';

import InputComponent from './InputComponent';
class MainComponent extends Component {
    // componentWillMount(){
    // console.log('inside main componentWillMount')

    // }
 
    constructor() {
        super();
       
    this.state = {
      userText : "",datePick :"", category: "",numberDoodle:"", errors:{}
    }
    this._formGroupClass =this._formGroupClass.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
    this._validate = this._validate.bind(this);
    this._onChange = this._onChange.bind(this);
  }

  _onSubmit(e) {
    console.log("isnide submit on")
    e.preventDefault();
    var errors = this._validate();
    if(Object.keys(errors).length != 0) {

      this.setState({
        errors: errors
      });
      return;
    }
   //make ajax request here tryit
  
      this.props.fetchData('https://jsonplaceholder.typicode.com/posts');
     //routing
      browserHistory.push('/dl/doodle');
  }


   _validate() {
    console.log("isnide validate on")

    var errors = {}
    if(this.state.userText == "") {
      errors.userText = "Some text is required";
    }
    if(this.state.datePick == "") {
      errors.datePick = "Date Field is required";
    }
    if(this.state.category == "") {
      errors.category = "category is required";
    }
     if(this.state.numberDoodle == "") {
      errors.numberDoodle = "Number of Doodles is required";
    }
    return errors;
  }

  _formGroupClass (field) {
    var className = "form-group ";
    if(field) {
      className += " has-error"
    }
    return className;
  }
   _onChange(e) {
    var state = { };
    var str =  $.trim(e.target.value);
    var UpperCaseString = str.toUpperCase();
    state[e.target.name] = UpperCaseString;

    this.setState(state);
   }

   
  
   

    render() {
        console.log('inisde main render');
        if (this.props.hasErrored) {
            return <p>Sorry! There was an error loading the items</p>;
        }

        if (this.props.isLoading) {
            return <p> Loading…</p>;
        }
        var newChildren =ReactChildrenCloneWithProps(this.props.children,{ 
            state:this.state,
         onChange1: this._onChange,
          formGroupClass: this._formGroupClass,
           onSubmit1: this._onSubmit,
           props: this.props

       });

        return (
          <div>
                {newChildren}
           
          </div>
        );
    }
}

MainComponent.propTypes = {
    fetchData: PropTypes.func.isRequired,
    items: PropTypes.array.isRequired,
    hasErrored: PropTypes.bool.isRequired,
    isLoading: PropTypes.bool.isRequired
};

const mapStateToProps = (state) => {
    return {
        items: state.items,
        hasErrored: state.itemsHasErrored,
        isLoading: state.itemsIsLoading
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchData: (url,data) => dispatch(itemsFetchData(url,data))
      };
};

export default connect(mapStateToProps, mapDispatchToProps)(MainComponent);
