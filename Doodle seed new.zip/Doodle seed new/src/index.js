import React from 'react';
import { render } from 'react-dom';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';

import { Provider } from 'react-redux';
import configureStore from './store/configureStore';

import Main from './components/MainComponent';
import InputComponent from './components/InputComponent.js';
import DoodleList from './components/DoodleList'

import './styles/styles.css';

const store = configureStore();

render(
    <Provider store={store}>
        <Router history={browserHistory}>
			<Route path="/" component={Main}>
				<IndexRoute component= {InputComponent}> </IndexRoute>
				<Route name="Doodle" path="/dl/:id" component={DoodleList}> </Route>
			</Route>
			
		</Router>
    </Provider>,
    document.getElementById('content')
);
